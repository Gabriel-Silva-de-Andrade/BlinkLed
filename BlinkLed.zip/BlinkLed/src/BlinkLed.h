#ifndef BlinkLed_h
#define BlinkLed_h

#include "Arduino.h"
	class BlinkLed{
	  public:
		BlinkLed(byte pin);
		void ONoff_Light(int tempoAceso, int tempoDesligado);
	  private:
		byte porta;
		unsigned long tempo_Decorrido;
		unsigned long inicio_Ciclo; 
	};

#endif	