#include "BlinkLed.h"

#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "Arduino.h"

BlinkLed::BlinkLed(byte pin){
  pinMode(pin, OUTPUT);
  porta = pin;
}

void BlinkLed::ONoff_Light(int tempoAceso, int tempoDesligado){

  tempo_Decorrido = millis() - inicio_Ciclo;
  
  if (tempo_Decorrido < tempoAceso){
    digitalWrite(porta, HIGH);
  }
  if (tempo_Decorrido >= tempoAceso){
    digitalWrite(porta, LOW);
  }
  if (tempo_Decorrido >  tempoDesligado + tempoAceso){
    inicio_Ciclo = millis();
  }
 }